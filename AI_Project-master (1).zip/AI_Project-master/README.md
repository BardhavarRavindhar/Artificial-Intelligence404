# AI_Project
Handwritten Digit Reccognition
